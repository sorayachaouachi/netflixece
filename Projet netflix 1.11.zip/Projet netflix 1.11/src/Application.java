import startingGate.LoginWindow;

public class Application   {

    public static void main(String[] args) {

        LoginWindow loginWindow = new LoginWindow();

    }



}
